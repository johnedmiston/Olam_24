<?php

if (!PERFORMING_MIGRATION) {
    die("Error: you can't run a migration directly");
}