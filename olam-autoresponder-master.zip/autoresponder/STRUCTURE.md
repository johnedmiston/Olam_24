# Endpoints

## Logged in required

* admin.php
* blacklist.php
* bouncers.php
* edit_config.php ( *redirects if not logged in* )
* index.php ( *redirects to admin.php* )
* mailbursts.php
* messages.php
* regexps.php
* responders.php
* tools.php

## No Login required
* bouncechecker.php
* confirm_subscription.php
* keep_subscription.php ( *Displays HTML* )
* list.php ( *Subscribe to list* )
* login.php
* logout.php
* move_subscriber.php ( *maybe should be logged in?* )
* resend_subscription_confirmation.php
* s.php
* subscribe.php

## Cron / Automation
* mailchecker.php
* sendmails-jaredval.php
* sendmails.php ( *should be called on regular basis* )

## HTML snippets
* popup_js.php
* tinyMCE_full.php
* tinyMCE_simple.php
* tinyMCE.php

# Common used code
* common.php
* class.phpmailer.php
* evilness-filter.php
* functions.php
* password.php
* PHPMailerAutoload.php
* subscriptions_common.php


# Config Files
* config.php

# Install Files
* check_install.php
* defs.sql
* gpl.txt
* silent_post.php

# Skeleton Files
* new_header.php
