<br />
<font size="5" color="#660000">
  <center>-- Confirmation Required --</center>
</font>
<br />
<center>
  <table width="750" bgcolor="#CCCCCC" style="border: 1px solid #000000">
    <tr>
      <td valign="top" width="200">
        <font size="4" color="#000066"><br />Subject:</font>
      </td>
      <td valign="top" width="740">
        <br /><font size="4" color="#003300"><?php echo $DB_MsgSub?></font>
        <br />
        <hr
          style="
            border: 0;
            background-color: #000000;
            color: #000000;
            height: 1px;
            width: 100%;
          "
        />
        <br />
      </td>
    </tr>
    <?php if ($DB_AttachmentStorageName != "") {?>
    <tr>
      <td valign="top">
        <font size="4" color="#000066">Attachment:</font>
      </td>
      <td valign="top">
        <font size="4" color="#003333"><?php echo $DB_AttachmentName?></font>
        <br>
        <hr
          style="
            border: 0;
            background-color: #000000;
            color: #000000;
            height: 1px;
            width: 100%;
          "
        />
        <br>
      </td>
    </tr>
    <?php } ?>
    <tr>
      <td valign="top" width="200">
        <font size="4" color="#000066">Body text:</font>
      </td>
      <td valign="top" width="740">
        <font size="4" color="#330033"
          ><?php echo nl2br($DB_MsgBodyText)?></font
        >
        <br />
        <hr
          style="
            border: 0;
            background-color: #000000;
            color: #000000;
            height: 1px;
            width: 100%;
          "
        />
        <br />
      </td>
    </tr>
    <tr>
      <td valign="top" width="200">
        <font size="4" color="#000066">Body HTML:</font>
      </td>
      <td valign="top" width="740">
        <font size="4" color="#003300"
          ><?php echo nl2br(htmlentities($DB_MsgBodyHTML))?></font
        >
        <br />
        <hr
          style="
            border: 0;
            background-color: #000000;
            color: #000000;
            height: 1px;
            width: 100%;
          "
        />
        <br />
      </td>
    </tr>
    <tr>
      <td valign="top" width="200">
        <font size="4" color="#000066">Run after:</font>
      </td>
      <td valign="top" width="740">
        <font size="4" color="#330033">
          <?php echo "$T_months months,$T_weeks weeks, $T_days days, $T_hours hours, $T_minutes minutes. (military time)\n";?>
        </font>
      </td>
    </tr>
    <tr>
      <td valign="top" width="200">
        <font size="4" color="#000066">Run on: (Optional)</font>
      </td>
      <td valign="top" width="740">
        <font size="4" color="#330033">
          <?php echo "$DB_absDay $DB_absHours hours : $DB_absMins mins.<br>\n";
          ?>
        </font>
      </td>
    </tr>
  </table>
  <br />
  <table cellspacing="10" border="0" width="100%">
    <tr>
      <td colspan="2">
        <br />
        <font size="4" color="#660000">
          <center>Delete this message?</center>
        </font>
      </td>
    </tr>
    <tr>
      <td>
        <FORM action="messages.php" method="POST">
          <input type="hidden" name="action" value="do_delete" />
          <input type="hidden" name="r_ID" value="<?php echo $Responder_ID?>" />
          <input type="hidden" name="MSG_ID" value="<?php echo $M_ID?>" />
          <p align="right">
            <input type="submit" name="Yes" value="Yes" />
          </p>
        </FORM>
      </td>
      <td>
        <FORM action="responders.php" method="POST">
          <input type="hidden" name="action" value="update" />
          <input type="hidden" name="r_ID" value="<?php echo $Responder_ID?>" />
          <p align="left">
            <input type="submit" name="No" value="No" />
          </p>
        </FORM>
      </td>
    </tr>
  </table>
</center>
