<?
# Beginning of template file.
# Add whatever you want here.
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
    "http://www.w3.org/TR/html4/loose.dtd">

<html>
<head>
    <title>Mailer Controls</title>
    <link rel="stylesheet" type="text/css" href="templates/main.css">
    <meta http-equiv=Content-Type content="text/html; charset=<?php echo $charset; ?>">
    <?php
    # If you're changing this file, you'll need to include this php in your version too.
    include("tinyMCE.php");
    ?>
</head>

<body>
<center>
    <table width="770" class="main_table" cellpadding="0" cellspacing="0" border="0">
        <tr>
            <td class="main_top_border" colspan="3"></td>
        </tr>
        <tr>
            <td class="main_left_border"></td>
            <td>
                <table cellpadding="0" cellspacing="0" border="0" width="760" class="body_table">
                    <tr>
                        <td>
                            <img src="images/ir_banner.jpg" border="0">
                        </td>
                    </tr>
                    <tr>
                        <td>
