<tr>
    <td colspan="4">
        <table align="right">
            <tr>
                <td>
                    <input type="hidden" name="r_ID" value="<?php echo $Responder_ID; ?>">
                    <input type="hidden" name="action" value="sub_addnew_do">
                    <input type="submit" name="save" value="Save" class="save_b">
                    </FORM>
                </td>
            </tr>
        </table>
    </td>
</tr>
</table>
</center>
