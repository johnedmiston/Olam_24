<p align="center" style="font-size: 150%">
    <font color="#660000"><?php echo $heading; ?></font>
</p>
<center>
    <table border="0" width="750" cellpadding="0" cellspacing="0" style="border: 1px solid #000000;">
        <tr>
            <td>
                <table border="0" width="100%" cellpadding="0" cellspacing="2" class="header_color">
                    <tr>
                        <td width="330"><font color="#000033">Subject</font></td>
                        <td width="320"><font color="#000033">Created on</font></td>
                        <td width="45">&nbsp;</td>
                        <td width="45">&nbsp;</td>
                    </tr>
                </table>
