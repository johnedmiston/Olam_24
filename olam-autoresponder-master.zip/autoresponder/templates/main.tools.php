<table cellpadding="0" cellspacing="10" border="0">
    <tr>
        <td>
            <FORM action="tools.php" method=POST>
                <input type="hidden" name="action" value="run_sendmails">
                <input type="submit" name="send" value="Run Sendmails" alt="Run Sendmails">
            </FORM>
        </td>
    </tr>
    <tr>
        <td>
            <FORM action="tools.php" method=POST>
                <input type="hidden" name="action" value="run_bouncechecker">
                <input type="submit" name="bounce" value="Run Bounce Checker" alt="Run Bounce Checker">
            </FORM>
        </td>
    </tr>
    <tr>
        <td>
            <FORM action="tools.php" method=POST>
                <input type="hidden" name="action" value="run_mailchecker">
                <input type="submit" name="mailc" value="Run Mail Checker" alt="Run Mail Checker">
            </FORM>
        </td>
    </tr>
</table>
