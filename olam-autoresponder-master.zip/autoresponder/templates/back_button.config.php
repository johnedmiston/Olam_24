<br/>
<div style="width:550px">
    <div style="width:50%; float: left;">
        <FORM action="admin.php" method=POST>
            <input type="hidden" name="action" value="list">
            <input type="submit" name="back" value="<< Back to Admin" alt="<< Back to Admin">
        </FORM>
    </div>
    <div style="width:50%; float: right;">
    </div>
</div>
</center>
