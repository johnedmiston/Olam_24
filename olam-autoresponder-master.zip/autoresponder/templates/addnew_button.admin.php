<table>
    <tr>
        <td width="600">&nbsp;</td>
        <td width="100">
            <form action="admin.php" method=POST>
                <input type="hidden" name="r_ID" value="<?php echo $Responder_ID; ?>">
                <input type="hidden" name="action" value="sub_addnew">
                <input type="submit" name="Add" value="Add Subscriber" class="butt">
            </form>
        </td>
    </tr>
</table>