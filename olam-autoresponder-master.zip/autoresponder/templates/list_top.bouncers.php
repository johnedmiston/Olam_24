<br/>
<center>
    <table border="0" width="750" cellpadding="0" cellspacing="0" style="border: 1px solid #000000;">
        <tr>
            <td>
                <table border="0" width="100%" cellpadding="0" cellspacing="2" class="header_color">
                    <tr>
                        <td width="50"><font color="#000033">Active</font></td>
                        <td width="300"><font color="#000033">Assigned Email</font></td>
                        <td width="300"><font color="#000033">Username</font></td>
                        <td width="45">&nbsp;</td>
                        <td width="45">&nbsp;</td>
                    </tr>
                </table>
