<hr style="border: 0; background-color: #660000; color: #660000; height: 1px; width: 100%;">
<p class="big_header">
    There are no messages for this responder!<br>
    Add one?
</p>
<hr style="border: 0; background-color: #660000; color: #660000; height: 1px; width: 100%;">
