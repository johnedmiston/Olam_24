<?php 
# ------------------------------------------------
# License and copyright:
# See license.txt for license information.
# ------------------------------------------------

# Database information goes here. Server, user, password and database.
$MySQL_server   = 'localhost';
$MySQL_user     = 'infinite';
$MySQL_password = 'put password here';
$MySQL_database = 'infinite';

# Place to store attachments. Please end the directory with /
$upload_directory = __DIR__ . '/storage/';

# ------------------------------------------------


# Get the rest of the config auto-magically

/*  mdevine - 09142018 - Commenting out because file doesn't exist 
include("get_config_vars.php");
*/
?>
